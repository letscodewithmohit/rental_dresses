// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyB4_rUnz_F2hoMrohtzjFuc94YlAv0O1iM",
    authDomain: "rentel-dresses.firebaseapp.com",
    projectId: "rentel-dresses",
    storageBucket: "rentel-dresses.appspot.com",
    messagingSenderId: "675668731969",
    appId: "1:675668731969:web:9cbb9fb54e484acc1d7ec0"
  };

  // Initialize Firebase
  const app = initializeApp(firebaseConfig);